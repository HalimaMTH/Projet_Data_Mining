import requests
from bs4 import BeautifulSoup
import time

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.8"
}


def scrape_products(query="laptop", site="jumia"):
    routers = {
        "jumia":      scrape_jumia,
        "books":      scrape_books,
        "avito":      scrape_avito,
        "amazon":     scrape_amazon,
        "aliexpress": scrape_aliexpress,
        "ebay":       scrape_ebay,
        "noon":       scrape_noon,
        "etsy":       scrape_etsy,
    }
    scraper = routers.get(site, scrape_jumia)
    return scraper(query)


def get_selenium_soup(url, wait=3):
    try:
        import undetected_chromedriver as uc
        options = uc.ChromeOptions()
        options.add_argument("--headless")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=1920,1080")
        driver = uc.Chrome(options=options)
        driver.get(url)
        time.sleep(wait)
        soup = BeautifulSoup(driver.page_source, "html.parser")
        driver.quit()
        return soup
    except Exception as e:
        print(f"Selenium error: {e}")
        return None


def scrape_jumia(query):
    BASE = "https://www.jumia.ma"
    url  = f"{BASE}/catalog/?q={query}"
    products = []
    try:
        response = requests.get(url, headers=HEADERS, timeout=10)
        if response.status_code != 200:
            return fallback_data(query, "jumia")
        soup  = BeautifulSoup(response.text, "html.parser")
        items = soup.find_all("article", class_="prd")
        for item in items[:12]:
            try:
                name_tag  = item.find("h3", class_="name")
                name      = name_tag.text.strip() if name_tag else "Produit inconnu"
                price_tag = item.find("div", class_="prc")
                if not price_tag:
                    continue
                price = float(price_tag.text.strip().replace("Dhs","").replace("DH","").replace(",","").strip())
                img_tag = item.find("img")
                image = ""
                if img_tag:
                    image = img_tag.get("data-src") or img_tag.get("data-srcset") or img_tag.get("src") or ""
                    if not image or image.startswith("data:"):
                        image = "https://via.placeholder.com/150"
                link_tag = item.find("a", class_="core")
                link = "#"
                if link_tag and link_tag.get("href"):
                    link = link_tag["href"]
                    if link.startswith("/"):
                        link = BASE + link
                products.append({"name": name, "price": price, "image": image, "link": link, "currency": "MAD", "rating": 4})
            except Exception:
                continue
        return products if products else fallback_data(query, "jumia")
    except Exception:
        return fallback_data(query, "jumia")


def scrape_books(query):
    BASE = "https://books.toscrape.com"
    products = []
    RATING_MAP = {"One": 1, "Two": 2, "Three": 3, "Four": 4, "Five": 5}
    for page in range(1, 6):
        try:
            page_url = f"{BASE}/catalogue/page-{page}.html"
            response = requests.get(page_url, headers=HEADERS, timeout=10)
            if response.status_code != 200:
                break
            soup  = BeautifulSoup(response.text, "html.parser")
            items = soup.find_all("article", class_="product_pod")
            for item in items:
                try:
                    name_tag = item.find("h3").find("a")
                    name     = name_tag["title"] if name_tag else "Unknown"
                    if query and query.lower() not in name.lower():
                        continue
                    price_tag  = item.find("p", class_="price_color")
                    price_text = price_tag.text.strip().replace("£","").replace("Â","").strip()
                    price_mad  = round(float(price_text) * 15, 2)
                    star_tag   = item.find("p", class_="star-rating")
                    rating     = RATING_MAP.get(star_tag["class"][1], 3) if star_tag else 3
                    link_tag   = item.find("h3").find("a")
                    link       = BASE + "/catalogue/" + link_tag["href"].replace("../","") if link_tag else "#"
                    img_tag    = item.find("img")
                    image      = BASE + "/" + img_tag["src"].replace("../","") if img_tag else ""
                    products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": rating})
                except Exception:
                    continue
            if len(products) >= 12:
                break
        except Exception:
            break
    return products[:12] if products else fallback_data(query, "books")


def scrape_avito(query):
    BASE = "https://www.avito.ma"
    url  = f"{BASE}/fr/maroc/tout?search[keywords]={query}"
    products = []
    soup = get_selenium_soup(url, wait=4)
    if not soup:
        return fallback_data(query, "avito")
    try:
        items = soup.find_all("a", attrs={"data-testid": "annonceCard-href"})
        if not items:
            items = soup.select("div[class*='sc-'] a[href*='/fr/']")
        for item in items[:12]:
            try:
                name_tag  = item.find(["h3","h2","p"], class_=lambda c: c and ("title" in c.lower() or "name" in c.lower()))
                name      = name_tag.text.strip() if name_tag else item.text.strip()[:80]
                if not name:
                    continue
                price_tag  = item.find(["p","span","div"], class_=lambda c: c and "price" in c.lower())
                if not price_tag:
                    continue
                price_text = ''.join(filter(lambda x: x.isdigit() or x == '.', price_tag.text.replace(" ","").replace("\xa0","")))
                price = float(price_text) if price_text else 0
                if price == 0:
                    continue
                img_tag = item.find("img")
                image   = img_tag.get("src") or img_tag.get("data-src") or "" if img_tag else ""
                href = item.get("href","#")
                link = BASE + href if href.startswith("/") else href
                products.append({"name": name, "price": price, "image": image, "link": link, "currency": "MAD", "rating": 3})
            except Exception:
                continue
    except Exception:
        pass
    return products if products else fallback_data(query, "avito")


def scrape_amazon(query):
    BASE = "https://www.amazon.com"
    url  = f"{BASE}/s?k={query}"
    products = []
    soup = get_selenium_soup(url, wait=4)
    if not soup:
        return fallback_data(query, "amazon")
    try:
        items = soup.find_all("div", {"data-component-type": "s-search-result"})
        for item in items[:12]:
            try:
                name_tag = (item.find("span", class_="a-size-medium") or item.find("span", class_="a-size-base-plus") or item.find("h2"))
                name = name_tag.text.strip() if name_tag else "Amazon Product"
                price_whole = item.find("span", class_="a-price-whole")
                if not price_whole:
                    continue
                price_fraction = item.find("span", class_="a-price-fraction")
                price_text = price_whole.text.replace(",","").replace(".","") + ("." + price_fraction.text if price_fraction else "")
                price_mad  = round(float(price_text) * 10, 2)
                img_tag  = item.find("img", class_="s-image")
                image    = img_tag["src"] if img_tag else ""
                link_tag = item.find("a", class_="a-link-normal")
                link     = BASE + link_tag["href"] if link_tag and link_tag.get("href") else "#"
                rating_tag = item.find("span", class_="a-icon-alt")
                rating = 4
                if rating_tag:
                    try:
                        rating = round(float(rating_tag.text.split()[0]))
                    except Exception:
                        pass
                products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": rating})
            except Exception:
                continue
    except Exception:
        pass
    return products if products else fallback_data(query, "amazon")


def scrape_aliexpress(query):
    BASE = "https://www.aliexpress.com"
    url  = f"{BASE}/wholesale?SearchText={query}"
    products = []
    soup = get_selenium_soup(url, wait=5)
    if not soup:
        return fallback_data(query, "aliexpress")
    try:
        items = soup.find_all("div", class_=lambda c: c and "product-card" in c.lower())
        if not items:
            items = soup.select("a[href*='/item/']")
        for item in items[:12]:
            try:
                name_tag  = item.find(["h1","h3","span"], class_=lambda c: c and "title" in c.lower())
                name      = name_tag.text.strip() if name_tag else "AliExpress Product"
                price_tag = item.find(["div","span"], class_=lambda c: c and "price" in c.lower())
                if not price_tag:
                    continue
                price_text = ''.join(filter(lambda x: x.isdigit() or x == '.', price_tag.text))
                price_mad  = round(float(price_text) * 10, 2) if price_text else 0
                if price_mad == 0:
                    continue
                img_tag = item.find("img")
                image   = img_tag.get("src") or img_tag.get("data-src") or "" if img_tag else ""
                if image.startswith("//"):
                    image = "https:" + image
                link_tag = item.find("a")
                href     = link_tag.get("href","#") if link_tag else "#"
                link     = "https:" + href if href.startswith("//") else href
                products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": 4})
            except Exception:
                continue
    except Exception:
        pass
    return products if products else fallback_data(query, "aliexpress")


def scrape_ebay(query):
    BASE = "https://www.ebay.com"
    url  = f"{BASE}/sch/i.html?_nkw={query}"
    products = []
    soup = get_selenium_soup(url, wait=3)
    if not soup:
        return fallback_data(query, "ebay")
    try:
        items = soup.find_all("li", class_="s-item")
        for item in items[:12]:
            try:
                name_tag = item.find("div", class_="s-item__title")
                name     = name_tag.text.strip() if name_tag else "eBay Item"
                if name in ("Shop on eBay",""):
                    continue
                price_tag = item.find("span", class_="s-item__price")
                if not price_tag:
                    continue
                price_text = price_tag.text.strip().replace("$","").replace(",","").split()[0]
                price_mad  = round(float(price_text) * 10, 2)
                img_tag  = item.find("img")
                image    = img_tag.get("src") or img_tag.get("data-src") or "" if img_tag else ""
                link_tag = item.find("a", class_="s-item__link")
                link     = link_tag["href"] if link_tag else "#"
                products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": 4})
            except Exception:
                continue
    except Exception:
        pass
    return products if products else fallback_data(query, "ebay")


def scrape_noon(query):
    BASE = "https://www.noon.com"
    url  = f"{BASE}/egypt-en/search/?q={query}"
    products = []
    try:
        response = requests.get(url, headers=HEADERS, timeout=12)
        if response.status_code != 200:
            return fallback_data(query, "noon")
        soup  = BeautifulSoup(response.text, "html.parser")
        import json
        scripts = soup.find_all("script", type="application/json")
        for script in scripts:
            try:
                data = json.loads(script.string or "")
                hits = data.get("hits",[]) or data.get("products",[])
                for h in hits[:12]:
                    name = h.get("name") or h.get("title") or "Noon Product"
                    price_egp = float(h.get("price",{}).get("value",0) or h.get("sale_price",0) or 0)
                    price_mad = round(price_egp * 0.57, 2)
                    image_keys = h.get("image_keys",[])
                    image = f"https://f.nooncdn.com/p/{image_keys[0]}n.jpg" if image_keys else ""
                    link  = BASE + "/egypt-en/" + h.get("sku","") + "/"
                    if price_mad > 0:
                        products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": 4})
                if products:
                    break
            except Exception:
                continue
        if not products:
            items = soup.find_all("div", attrs={"data-qa": "product-card"})
            for item in items[:12]:
                try:
                    name_tag  = item.find(["h2","h3","p"])
                    name      = name_tag.text.strip() if name_tag else "Noon Product"
                    price_tag = item.find(["span","div"], class_=lambda c: c and "price" in (c or "").lower())
                    if not price_tag:
                        continue
                    price_text = ''.join(c for c in price_tag.text if c.isdigit() or c == '.')
                    price_egp  = float(price_text) if price_text else 0
                    price_mad  = round(price_egp * 0.57, 2)
                    if price_mad == 0:
                        continue
                    img_tag  = item.find("img")
                    image    = img_tag.get("src") or img_tag.get("data-src") or "" if img_tag else ""
                    link_tag = item.find("a")
                    href     = link_tag.get("href","#") if link_tag else "#"
                    link     = BASE + href if href.startswith("/") else href
                    products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": 4})
                except Exception:
                    continue
    except Exception:
        pass
    return products[:12] if products else fallback_data(query, "noon")


def scrape_etsy(query):
    BASE = "https://www.etsy.com"
    url  = f"{BASE}/search?q={query}"
    products = []
    try:
        response = requests.get(url, headers={**HEADERS, "Accept": "text/html"}, timeout=12)
        if response.status_code != 200:
            return fallback_data(query, "etsy")
        soup  = BeautifulSoup(response.text, "html.parser")
        items = soup.find_all("div", class_=lambda c: c and "v2-listing-card" in (c or ""))
        if not items:
            items = soup.select("[data-listing-id]")
        for item in items[:12]:
            try:
                name_tag = item.find(["h3","h2"], class_=lambda c: c and "title" in (c or "").lower())
                if not name_tag:
                    name_tag = item.find(["h3","h2"])
                name = name_tag.text.strip() if name_tag else "Etsy Product"
                price_tag = item.find("span", class_=lambda c: c and "currency-value" in (c or ""))
                if not price_tag:
                    price_tag = item.find(["span","p"], class_=lambda c: c and "price" in (c or "").lower())
                if not price_tag:
                    continue
                price_text = ''.join(c for c in price_tag.text if c.isdigit() or c == '.')
                price_usd  = float(price_text) if price_text else 0
                price_mad  = round(price_usd * 10.2, 2)
                if price_mad == 0:
                    continue
                img_tag = item.find("img")
                image   = img_tag.get("src") or img_tag.get("data-src") or "" if img_tag else ""
                if image and "75x75" in image:
                    image = image.replace("75x75","300x300")
                link_tag = item.find("a")
                href     = link_tag.get("href","#") if link_tag else "#"
                link     = href if href.startswith("http") else BASE + href
                products.append({"name": name, "price": price_mad, "image": image, "link": link, "currency": "MAD", "rating": 5})
            except Exception:
                continue
    except Exception:
        pass
    return products[:12] if products else fallback_data(query, "etsy")


def fallback_data(query, site="jumia"):
    site_links = {
        "jumia":      f"https://www.jumia.ma/catalog/?q={query}",
        "books":      "https://books.toscrape.com",
        "avito":      f"https://www.avito.ma/fr/maroc/tout?search[keywords]={query}",
        "amazon":     f"https://www.amazon.com/s?k={query}",
        "aliexpress": f"https://www.aliexpress.com/wholesale?SearchText={query}",
        "ebay":       f"https://www.ebay.com/sch/i.html?_nkw={query}",
        "noon":       f"https://www.noon.com/egypt-en/search/?q={query}",
        "etsy":       f"https://www.etsy.com/search?q={query}",
    }
    base_link = site_links.get(site, "#")
    return [
        {"name": f"{query} — Product A", "price": 3500, "image": "https://via.placeholder.com/150", "link": base_link, "currency": "MAD", "rating": 4},
        {"name": f"{query} — Product B", "price": 4800, "image": "https://via.placeholder.com/150", "link": base_link, "currency": "MAD", "rating": 5},
        {"name": f"{query} — Product C", "price": 6200, "image": "https://via.placeholder.com/150", "link": base_link, "currency": "MAD", "rating": 3},
    ]
